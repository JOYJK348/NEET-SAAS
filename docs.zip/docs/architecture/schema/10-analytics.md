# 📊 Analytics & Reporting Domain Database Schema

> **Domain:** Materialized Dashboards, Key Performance Indicators (KPIs) & Aggregations  
> **Owner Team:** Platform / Analytics Team  
> **Database:** PostgreSQL (Supabase)  
> **Schema Version:** 1.0  
> **Status:** 🟢 Locked  
> **Parent ERD:** `docs/architecture/erd/10-analytics.md`  
> **Last Reviewed By:** — (Pending)

---

## 1. Overview

**Purpose:** The Analytics Domain manages computed dashboards, materialized reporting aggregates, and student/counselor tracking KPI metrics. Instead of executing direct joins across millions of hot database rows (attendance, responses, transactions) during active portal sessions, this domain decouples reads via scheduler-driven materialized views and incremental aggregate cache tables.

**Contains:**
- Materialized Views Registry (Schedules for refresh cycles)
- Dashboard KPI Snapshot (Aggregated numbers: revenues, active counts)
- Student Performance Summary (AI-ready weak topic and average grade metrics cache)
- Counselor Conversion Analytics (Pipeline SLA and efficiency trackers)
- Daily Branch Attendance Aggregation (Attendance metrics tracking)

**Domain Type:** 🧊 Cold / 🟡 Warm — Writes (aggregations refreshes) occur periodically via scheduler cron jobs. Reads are continuous for analytics charts.

---

## 2. Business Scope

### ✅ Included
- Materialized view refresh configurations (weekly, daily, hourly tracking triggers)
- Pre-aggregated dashboard statistics to speed up landing page load times (P95 < 5ms)
- Subject-wise student scores tracking registers (AI personalized dashboard inputs)
- Counselor sales cycle attribution performance statistics (SLA, conversion rates, lost attributions)
- Dynamic date-based branch attendance snapshots

### ❌ Excluded
- **Raw Event Logs** → System Domain (`11-system.md`) — Live clickstreams or request logs.
- **Financial Balances Ledger** → Fee Domain (`07-fee-management.md`) — The master transaction history and double-entry files.

---

## 2b. Domain Dependency Graph

```mermaid
graph TD
    %% Upstream Dependencies
    Institute[01 Institute Domain] --> Analytics[10 Analytics Domain]
    Students[04 Student Domain] --> Analytics
    Attendance[05 Attendance Domain] --> Analytics
    Assessment[06 Assessment Domain] --> Analytics
    Fees[07 Fee Domain] --> Analytics
    CRM[09 CRM Domain] --> Analytics

    %% Context Maps
    subgraph Core Aggregations Links
        Analytics -- "Aggregates Branch counts" --> Institute
        Analytics -- "Summarizes student profiles" --> Students
        Analytics -- "Aggregates presence ratios" --> Attendance
        Analytics -- "Aggregates score distributions" --> Assessment
        Analytics -- "Aggregates revenue metrics" --> Fees
        Analytics -- "Aggregates pipeline conversion funnels" --> CRM
    end
```

---

## 2c. Business Invariants

> Core architectural constraints enforced at database and application layers.

1. **Decoupled Reads**: Real-time business dashboard screens must query only pre-calculated KPI snapshots or materialized views, never raw tables.
2. **Immutable Snapshots**: Dashboard metrics snapshots, once saved at the end of a reporting period (e.g. daily/monthly closes), must not be altered to preserve audit histories.
3. **Out-of-Hours Refreshes**: Heavy materialized views calculation cron jobs must run during off-peak windows (between 00:00 and 04:00 local time).

---

## 3. Lifecycle & State Machines

### Materialized View Status

```text
    ┌──────────┐         ┌──────────┐         ┌──────────┐
    │  ACTIVE  │────────→│REFRESHING│────────→│  FAILED  │
    └──────────┘         └──────────┘         └──────────┘
```

---

## 4. Usage Pattern & Access Matrix

### 4.1 Access Pattern (Read/Write Ratio)

| Entity | Read % | Write % | Update % | Delete % | Pattern | Owner Team |
|---|---|---|---|---|---|---|
| Dashboard KPI | 95% | 5% | 0% | 0% | Read-heavy | Platform Team |
| Student Summary | 90% | 10% | 0% | 0% | Read-heavy | Academic Team |
| Counselor Stats | 95% | 5% | 0% | 0% | Read-heavy | Operations Team |
| Attendance Agg | 95% | 5% | 0% | 0% | Read-heavy | Operations Team |

---

## 5. Growth Forecast & Capacity Planning

### 5.1 Row Count Projection (3 Years)

| Entity | Year 1 | Year 3 | Growth Pattern |
|---|---|---|---|
| Dashboard KPI | 300,000 | 9,000,000 | Daily snapshots scoped by branch |
| Student Summary | 20,000 | 500,000 | 1:1 with active students |
| Counselor Stats | 100 | 2,000 | Scoped by counselors |
| Attendance Agg | 36,500 | 1,000,000 | Daily branch records |

---

## 6. Performance Budget

| Query | P50 | P95 | P99 | Cold Start | Notes |
|---|---|---|---|---|---|
| Q1 — Get Dashboard KPIs | < 2ms | < 5ms | < 12ms | < 50ms | B-tree index lookup |
| Q2 — Load Counselor stats | < 3ms | < 8ms | < 20ms | < 80ms | Scoped counsellor query |

---

## 7. Query Patterns ⭐

### Query 1 — Fetch Tenant Landing Page Stats

| Property | Value |
|---|---|
| **Screen** | Tenant Admin Dashboard |
| **Purpose** | Get active metrics counts (active students, active campaigns, today's collections) |
| **Input** | `institute_id`, `branch_id`, `snapshot_date = today` |
| **Output** | JSON metrics key-values |
| **Cardinality** | 1:1 lookup |
| **Index Used** | `idx_dashboard_kpis_lookup` |

---

## 8. Entity Design

### 9.1 `dashboard_kpi_snapshots`

**Purpose:** Caches aggregated counts for landing page dashboard widgets.

#### Columns

| Column | Type | Nullable | Default | Business Purpose |
|---|---|---|---|---|
| `id` | UUID | No | `gen_random_uuid()` | Primary Key |
| `institute_id` | UUID | No | - | FK → `institutes.id` |
| `branch_id` | UUID | Yes | - | FK → `branches.id` |
| `snapshot_date` | DATE | No | - | Aggregation date |
| `metrics` | JSONB | No | - | Mapped counts (e.g. `{"active_students": 1200}`) |
| `created_at` | TIMESTAMPTZ | No | `now()` | Log time |

---

### 9.2 `student_performance_summaries`

**Purpose:** Caches performance averages for AI dashboards.

#### Columns

| Column | Type | Nullable | Default | Business Purpose |
|---|---|---|---|---|
| `id` | UUID | No | `gen_random_uuid()` | Primary Key |
| `student_profile_id` | UUID | No | - | FK → `student_profiles.id` |
| `average_score` | NUMERIC(5,2) | No | - | Total exam average |
| `rank_in_batch` | INT | Yes | - | Current rank standing |
| `weak_topics` | VARCHAR(100)[]| Yes | - | AI derived tags array |
| `last_calculated_at` | TIMESTAMPTZ | No | `now()` | Evaluation run |

---

### 9.3 `counsellor_conversion_analytics`

**Purpose:** Tracks pipeline stats.

#### Columns

| Column | Type | Nullable | Default | Business Purpose |
|---|---|---|---|---|
| `id` | UUID | No | `gen_random_uuid()` | Primary Key |
| `user_id` | UUID | No | - | FK → `users.id` |
| `total_leads` | INT | No | `0` | Funnel checks |
| `converted_leads` | INT | No | `0` | Funnel checks |
| `conversion_rate` | NUMERIC(5,2) | No | - | Ratio |
| `avg_response_time_sec`| INT | Yes | - | SLA marker |

---

### 9.4 `daily_branch_attendance_aggregations`

**Purpose:** Caches branch-wide daily check-in data.

#### Columns

| Column | Type | Nullable | Default | Business Purpose |
|---|---|---|---|---|
| `id` | UUID | No | `gen_random_uuid()` | Primary Key |
| `branch_id` | UUID | No | - | FK → `branches.id` |
| `record_date` | DATE | No | - | Tracking date |
| `present_count` | INT | No | `0` | Aggregation count |
| `absent_count` | INT | No | `0` | Aggregation count |
| `late_count` | INT | No | `0` | Aggregation count |

---

## 10. Constraints

### Database-Enforced Constraints

| Constraint Name | Type | Table | Columns | Business Rule |
|---|---|---|---|---|
| `uq_dashboard_kpi_lookup` | Unique | `dashboard_kpi_snapshots` | `(institute_id, branch_id, snapshot_date)` | One snapshot row per branch per day |

---

## 11. Index Strategy

| Index Name | Table | Columns | Include (Covering) | Supports Query | Type | Justification |
|---|---|---|---|---|---|---|
| `idx_dashboard_kpis_lookup` | `dashboard_kpi_snapshots` | `(institute_id, branch_id, snapshot_date)` | `(metrics)` | Q1 | B-tree | Pre-aggregated values lookup |

---

## Appendix: Domain Notes

### Naming Conventions
- Tables: `dashboard_kpi_snapshots`, `student_performance_summaries`, `counsellor_conversion_analytics`, `daily_branch_attendance_aggregations`.

*Last updated: July 8, 2026*
