# ADR-005: Table Partitioning Strategy

## Context and Problem Statement

High-volume tables (`attendance_records` ~225M, `audit_logs` ~250M) degrade in indexing scan performance over a 3-year timeline.

## Decision Outcome

Chosen Option: **PostgreSQL Declarative Range Partitioning by Month**.

### Rules

1. Partition key: `created_at` (TIMESTAMPTZ) / `check_in_at` (TIMESTAMPTZ).
2. Scheduler crons automatically create next month's partition tables off-peak.
